# Bitcoin Rich Wallet Private Key Finder


Bitcoin Rich Wallet Private Key Finder From List

---
![Bitcoin Rich Wallet Private Key Finder](https://raw.githubusercontent.com/Pymmdrza/BTCRichWalletPrivateKeyFinder/mainx/btc.jpg)

For Running On Windows :

first install package's :

```
pip install hdwallet
pip install colorama
```
after installing run with this common: (download rich wallet list btc.txt)
```
python richbtc.py
```

for linux first install package's :
```
pip install hdwallet
pip install colorama
```
after installing run with this common: (download rich wallet list btc.txt)
```
python3 richbtc.py
or
sh richbtc.sh
```
