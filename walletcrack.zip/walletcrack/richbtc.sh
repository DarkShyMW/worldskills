while :
do
  python3 richbtc.py
done  
  
  
