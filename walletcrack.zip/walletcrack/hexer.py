# =====================================================
# DONATE (BTC) : 16p9y6EstGYcnofGNvUJMEGKiAWhAr1uR8
# Website : Mmdrza.Com
# Email : X4@mmdrza.Com
# Dev.to/Mmdrza
# Github.com/Pymmdrza
# =====================================================

#              ||================================||
#              ||- ╔╦╗╔╦╗╔╦╗╦═╗╔═╗╔═╗ ╔═╗╔═╗╔╦╗ -||
#              ||- ║║║║║║ ║║╠╦╝╔═╝╠═╣ ║  ║ ║║║║ -||
#              ||- ╩ ╩╩ ╩═╩╝╩╚═╚═╝╩ ╩o╚═╝╚═╝╩ ╩ -||
#              ||--------------------------------||
#              ||-| WebSite : Mmdrza.Com        -||
#              ||-| Mail : X4@Mmdrza.Com        -||
#              ||-| DEV.to/Mmdrza               -||
#              ||-| Github.Com/PyMmdrza         -||
#              ||-| PythonWithMmdrza.Medium.Com -||
#              ||================================||
#              ||================================||
#              ||================================||
# -----------------------------------------------------------------------------------------------------------------


import random


def mHash():
    bx1 = str(random.choice('123456789abcdef'))

    bx2 = str(random.choice('123456789abcdef'))

    bx3 = str(random.choice('123456789abcdef'))

    bx4 = str(random.choice('123456789abcdef'))

    bx5 = str(random.choice('123456789abcdef'))

    bx6 = str(random.choice('123456789abcdef'))

    bx7 = str(random.choice('123456789abcdef'))

    bx8 = str(random.choice('123456789abcdef'))

    bx9 = str(random.choice('123456789abcdef'))

    bx10 = str(random.choice('123456789abcdef'))

    bx11 = str(random.choice('123456789abcdef'))

    bx12 = str(random.choice('123456789abcdef'))

    bx13 = str(random.choice('123456789abcdef'))

    bx14 = str(random.choice('123456789abcdef'))

    bx15 = str(random.choice('123456789abcdef'))

    bx16 = str(random.choice('123456789abcdef'))

    bx17 = str(random.choice('123456789abcdef'))

    bx18 = str(random.choice('123456789abcdef'))

    bx19 = str(random.choice('123456789abcdef'))

    bx20 = str(random.choice('123456789abcdef'))

    bx21 = str(random.choice('123456789abcdef'))

    bx22 = str(random.choice('123456789abcdef'))

    bx23 = str(random.choice('123456789abcdef'))

    bx24 = str(random.choice('123456789abcdef'))

    bx25 = str(random.choice('123456789abcdef'))

    bx26 = str(random.choice('123456789abcdef'))

    bx27 = str(random.choice('123456789abcdef'))

    bx28 = str(random.choice('123456789abcdef'))

    bx29 = str(random.choice('123456789abcdef'))

    bx30 = str(random.choice('123456789abcdef'))

    bx31 = str(random.choice('123456789abcdef'))

    bx32 = str(random.choice('123456789abcdef'))

    bx33 = str(random.choice('123456789abcdef'))

    bx34 = str(random.choice('123456789abcdef'))

    bx35 = str(random.choice('123456789abcdef'))

    bx36 = str(random.choice('123456789abcdef'))

    bx37 = str(random.choice('123456789abcdef'))

    bx38 = str(random.choice('123456789abcdef'))

    bx39 = str(random.choice('123456789abcdef'))

    bx40 = str(random.choice('123456789abcdef'))

    bx41 = str(random.choice('123456789abcdef'))

    bx42 = str(random.choice('123456789abcdef'))

    bx43 = str(random.choice('123456789abcdef'))

    bx44 = str(random.choice('123456789abcdef'))

    bx45 = str(random.choice('123456789abcdef'))

    bx46 = str(random.choice('123456789abcdef'))

    bx47 = str(random.choice('123456789abcdef'))

    bx48 = str(random.choice('123456789abcdef'))

    bx49 = str(random.choice('123456789abcdef'))

    bx50 = str(random.choice('123456789abcdef'))

    bx51 = str(random.choice('123456789abcdef'))

    bx52 = str(random.choice('123456789abcdef'))

    bx53 = str(random.choice('123456789abcdef'))

    bx54 = str(random.choice('123456789abcdef'))

    bx55 = str(random.choice('123456789abcdef'))

    bx56 = str(random.choice('123456789abcdef'))

    bx57 = str(random.choice('123456789abcdef'))

    bx58 = str(random.choice('123456789abcdef'))

    bx59 = str(random.choice('123456789abcdef'))

    bx60 = str(random.choice('123456789abcdef'))

    bx61 = str(random.choice('123456789abcdef'))

    bx62 = str(random.choice('123456789abcdef'))

    bx63 = str(random.choice('123456789abcdef'))

    bx64 = str(random.choice('123456789abcdef'))

    metax = (
                str(bx1) + str(bx2) + str(bx3) + str(bx4) + str(bx5) + str(bx6) + str(bx7) + str(bx8) + str(bx9) + str(bx10) + str(bx11) + str(bx12) + str(bx13) + str(bx14) + str(bx15) + str(bx16) + str(bx17) + str(bx18) + str(bx19) + str(bx20) + str(bx21) + str(bx22) + str(bx23) + str(bx24) + str(bx25) + str(bx26) + str(bx27) + str(bx28) + str(bx29) + str(bx30) + str(bx31) + str(bx32) + str(bx33) + str(bx34) + str(bx35) + str(bx36) + str(bx37) + str(bx38) + str(bx39) + str(bx40) + str(bx41) + str(bx42) + str(bx43) + str(bx44) + str(bx45) + str(bx46) + str(bx47) + str(bx48) + str(bx49) + str(bx50) + str(bx51) + str(bx52) + str(bx53) + str(bx54) + str(bx55) + str(bx56) + str(bx57) + str(bx58) + str(bx59) + str(bx60) + str(bx61) + str(bx62) + str(bx63) + str(bx64))
    return metax


def mhex128():
    ua1 = str(random.choice('0123456789abcdef'))
    ua2 = str(random.choice('0123456789abcdef'))
    ua3 = str(random.choice('0123456789abcdef'))
    ua4 = str(random.choice('0123456789abcdef'))
    ua5 = str(random.choice('0123456789abcdef'))
    ua6 = str(random.choice('0123456789abcdef'))
    ua7 = str(random.choice('0123456789abcdef'))
    ua8 = str(random.choice('0123456789abcdef'))
    ua9 = str(random.choice('0123456789abcdef'))
    ua10 = str(random.choice('0123456789abcdef'))
    ua11 = str(random.choice('0123456789abcdef'))
    ua12 = str(random.choice('0123456789abcdef'))
    ua13 = str(random.choice('0123456789abcdef'))
    ua14 = str(random.choice('0123456789abcdef'))
    ua15 = str(random.choice('0123456789abcdef'))
    ua16 = str(random.choice('0123456789abcdef'))
    ua17 = str(random.choice('0123456789abcdef'))
    ua18 = str(random.choice('0123456789abcdef'))
    ua19 = str(random.choice('0123456789abcdef'))
    ua20 = str(random.choice('0123456789abcdef'))
    ua21 = str(random.choice('0123456789abcdef'))
    ua22 = str(random.choice('0123456789abcdef'))
    ua23 = str(random.choice('0123456789abcdef'))
    ua24 = str(random.choice('0123456789abcdef'))
    ua25 = str(random.choice('0123456789abcdef'))
    ua26 = str(random.choice('0123456789abcdef'))
    ua27 = str(random.choice('0123456789abcdef'))
    ua28 = str(random.choice('0123456789abcdef'))
    ua29 = str(random.choice('0123456789abcdef'))
    ua30 = str(random.choice('0123456789abcdef'))
    ua31 = str(random.choice('0123456789abcdef'))
    ua32 = str(random.choice('0123456789abcdef'))
    ua33 = str(random.choice('0123456789abcdef'))
    ua34 = str(random.choice('0123456789abcdef'))
    ua35 = str(random.choice('0123456789abcdef'))
    ua36 = str(random.choice('0123456789abcdef'))
    ua37 = str(random.choice('0123456789abcdef'))
    ua38 = str(random.choice('0123456789abcdef'))
    ua39 = str(random.choice('0123456789abcdef'))
    ua40 = str(random.choice('0123456789abcdef'))
    ua41 = str(random.choice('0123456789abcdef'))
    ua42 = str(random.choice('0123456789abcdef'))
    ua43 = str(random.choice('0123456789abcdef'))
    ua44 = str(random.choice('0123456789abcdef'))
    ua45 = str(random.choice('0123456789abcdef'))
    ua46 = str(random.choice('0123456789abcdef'))
    ua47 = str(random.choice('0123456789abcdef'))
    ua48 = str(random.choice('0123456789abcdef'))
    ua49 = str(random.choice('0123456789abcdef'))
    ua50 = str(random.choice('0123456789abcdef'))
    ua51 = str(random.choice('0123456789abcdef'))
    ua52 = str(random.choice('0123456789abcdef'))
    ua53 = str(random.choice('0123456789abcdef'))
    ua54 = str(random.choice('0123456789abcdef'))
    ua55 = str(random.choice('0123456789abcdef'))
    ua56 = str(random.choice('0123456789abcdef'))
    ua57 = str(random.choice('0123456789abcdef'))
    ua58 = str(random.choice('0123456789abcdef'))
    ua59 = str(random.choice('0123456789abcdef'))
    ua60 = str(random.choice('0123456789abcdef'))
    ua61 = str(random.choice('0123456789abcdef'))
    ua62 = str(random.choice('0123456789abcdef'))
    ua63 = str(random.choice('0123456789abcdef'))
    ua64 = str(random.choice('0123456789abcdef'))
    ua65 = str(random.choice('0123456789abcdef'))
    ua66 = str(random.choice('0123456789abcdef'))
    ua67 = str(random.choice('0123456789abcdef'))
    ua68 = str(random.choice('0123456789abcdef'))
    ua69 = str(random.choice('0123456789abcdef'))
    ua70 = str(random.choice('0123456789abcdef'))
    ua71 = str(random.choice('0123456789abcdef'))
    ua72 = str(random.choice('0123456789abcdef'))
    ua73 = str(random.choice('0123456789abcdef'))
    ua74 = str(random.choice('0123456789abcdef'))
    ua75 = str(random.choice('0123456789abcdef'))
    ua76 = str(random.choice('0123456789abcdef'))
    ua77 = str(random.choice('0123456789abcdef'))
    ua78 = str(random.choice('0123456789abcdef'))
    ua79 = str(random.choice('0123456789abcdef'))
    ua80 = str(random.choice('0123456789abcdef'))
    ua81 = str(random.choice('0123456789abcdef'))
    ua82 = str(random.choice('0123456789abcdef'))
    ua83 = str(random.choice('0123456789abcdef'))
    ua84 = str(random.choice('0123456789abcdef'))
    ua85 = str(random.choice('0123456789abcdef'))
    ua86 = str(random.choice('0123456789abcdef'))
    ua87 = str(random.choice('0123456789abcdef'))
    ua88 = str(random.choice('0123456789abcdef'))
    ua89 = str(random.choice('0123456789abcdef'))
    ua90 = str(random.choice('0123456789abcdef'))
    ua91 = str(random.choice('0123456789abcdef'))
    ua92 = str(random.choice('0123456789abcdef'))
    ua93 = str(random.choice('0123456789abcdef'))
    ua94 = str(random.choice('0123456789abcdef'))
    ua95 = str(random.choice('0123456789abcdef'))
    ua96 = str(random.choice('0123456789abcdef'))
    ua97 = str(random.choice('0123456789abcdef'))
    ua98 = str(random.choice('0123456789abcdef'))
    ua99 = str(random.choice('0123456789abcdef'))
    ua100 = str(random.choice('0123456789abcdef'))
    ua101 = str(random.choice('0123456789abcdef'))
    ua102 = str(random.choice('0123456789abcdef'))
    ua103 = str(random.choice('0123456789abcdef'))
    ua104 = str(random.choice('0123456789abcdef'))
    ua105 = str(random.choice('0123456789abcdef'))
    ua106 = str(random.choice('0123456789abcdef'))
    ua107 = str(random.choice('0123456789abcdef'))
    ua108 = str(random.choice('0123456789abcdef'))
    ua109 = str(random.choice('0123456789abcdef'))
    ua110 = str(random.choice('0123456789abcdef'))
    ua111 = str(random.choice('0123456789abcdef'))
    ua112 = str(random.choice('0123456789abcdef'))
    ua113 = str(random.choice('0123456789abcdef'))
    ua114 = str(random.choice('0123456789abcdef'))
    ua115 = str(random.choice('0123456789abcdef'))
    ua116 = str(random.choice('0123456789abcdef'))
    ua117 = str(random.choice('0123456789abcdef'))
    ua118 = str(random.choice('0123456789abcdef'))
    ua119 = str(random.choice('0123456789abcdef'))
    ua120 = str(random.choice('0123456789abcdef'))
    ua121 = str(random.choice('0123456789abcdef'))
    ua122 = str(random.choice('0123456789abcdef'))
    ua123 = str(random.choice('0123456789abcdef'))
    ua124 = str(random.choice('0123456789abcdef'))
    ua125 = str(random.choice('0123456789abcdef'))
    ua126 = str(random.choice('0123456789abcdef'))
    ua127 = str(random.choice('0123456789abcdef'))
    ua128 = str(random.choice('0123456789abcdef'))
    letgt = str(ua1) + str(ua2) + str(ua3) + str(ua4) + str(ua5) + str(ua6) + str(ua7) + str(ua8) + str(ua9) + str(ua10) + str(ua11) + str(ua12) + str(ua13) + str(ua14) + str(ua15) + str(ua16) + str(ua17) + str(ua18) + str(ua19) + str(ua20) + str(ua21) + str(ua22) + str(ua23) + str(ua24) + str(ua25) + str(ua26) + str(ua27) + str(ua28) + str(ua29) + str(ua30) + str(ua31) + str(ua32) + str(ua33) + str(ua34) + str(ua35) + str(ua36) + str(ua37) + str(ua38) + str(ua39) + str(ua40) + str(ua41) + str(ua42) + str(ua43) + str(ua44) + str(ua45) + str(ua46) + str(ua47) + str(ua48) + str(ua49) + str(ua50) + str(ua51) + str(ua52) + str(ua53) + str(ua54) + str(ua55) + str(ua56) + str(ua57) + str(ua58) + str(ua59) + str(ua60) + str(ua61) + str(ua62) + str(ua63) + str(ua64) + str(ua65) + str(ua66) + str(ua67) + str(ua68) + str(ua69) + str(ua70) + str(ua71) + str(ua72) + str(ua73) + str(ua74) + str(ua75) + str(ua76) + str(ua77) + str(ua78) + str(ua79) + str(ua80) + str(ua81) + str(ua82) + str(ua83) + str(ua84) + str(ua85) + str(ua86) + str(ua87) + str(ua88) + str(ua89) + str(ua90) + str(ua91) + str(ua92) + str(ua93) + str(ua94) + str(ua95) + str(ua96) + str(ua97) + str(ua98) + str(ua99) + str(ua100) + str(ua101) + str(ua102) + str(ua103) + str(ua104) + str(ua105) + str(ua106) + str(ua107) + str(ua108) + str(ua109) + str(ua110) + str(ua111) + str(ua112) + str(ua113) + str(ua114) + str(ua115) + str(ua116) + str(ua117) + str(ua118) + str(ua119) + str(ua120) + str(ua121) + str(ua122) + str(ua123) + str(ua124) + str(ua125) + str(ua126) + str(ua127) + str(ua128)
    return letgt

# =====================================================
# DONATE (BTC) : 16p9y6EstGYcnofGNvUJMEGKiAWhAr1uR8
# Website : Mmdrza.Com
# Email : X4@mmdrza.Com
# Dev.to/Mmdrza
# Github.com/Pymmdrza
# =====================================================